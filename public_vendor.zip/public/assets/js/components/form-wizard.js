/*
Template Name: Larkon - Responsive 5 Admin Dashboard
Author: Techzaa
File: wizard Js File
*/

new Wizard('#horizontalwizard');

new Wizard('#verticalwizard');